"""
analyzer.py - Security misconfiguration checks for WebRecon.

Takes the ScanResult produced by scanner.py and turns it into a list of
Findings, each with a severity, evidence, and a remediation recommendation.
Every check is a small standalone function so it can be unit tested.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, asdict
from urllib.parse import urlparse

from scanner import ScanResult

SEVERITY_ORDER = {"Critical": 0, "High": 1, "Medium": 2, "Low": 3, "Info": 4}

SESSION_COOKIE_HINTS = ("sess", "sid", "auth", "token", "jwt", "login", "remember")
CSRF_FIELD_HINTS = ("csrf", "xsrf", "token", "authenticity", "nonce", "__requestverification")


@dataclass
class Finding:
    check_id: str
    title: str
    severity: str
    category: str
    description: str
    evidence: str
    recommendation: str

    def to_dict(self) -> dict:
        return asdict(self)


def _headers_lower(result: ScanResult) -> dict:
    return {k.lower(): v for k, v in result.headers.items()}


def _is_https(result: ScanResult) -> bool:
    return urlparse(result.final_url or result.target).scheme == "https"


# ---------------------------------------------------------------- transport

def check_https(result: ScanResult) -> list[Finding]:
    if _is_https(result):
        return []
    return [Finding(
        "WR-001", "Site served over unencrypted HTTP", "Medium", "Transport Security",
        "The application responded over plain HTTP. Traffic, including credentials and "
        "session cookies, can be read or modified by anyone on the network path.",
        f"Final URL: {result.final_url or result.target}",
        "Serve the application over HTTPS and redirect all HTTP requests to HTTPS.",
    )]


# ---------------------------------------------------------- security headers

HEADER_CHECKS = [
    # header, check id, severity, why it matters, recommended value
    ("content-security-policy", "WR-010", "Medium",
     "No Content Security Policy was set, so the browser has no restriction on where "
     "scripts and other resources can load from. This makes cross-site scripting easier to exploit.",
     "Add a Content-Security-Policy header, starting with something like default-src 'self'."),
    ("x-content-type-options", "WR-012", "Low",
     "Without X-Content-Type-Options the browser may guess content types, which can turn "
     "an uploaded file into executable script.",
     "Add X-Content-Type-Options: nosniff."),
    ("referrer-policy", "WR-013", "Low",
     "No Referrer-Policy was set, so full URLs including query strings may leak to other sites.",
     "Add Referrer-Policy: strict-origin-when-cross-origin or stricter."),
    ("permissions-policy", "WR-014", "Info",
     "No Permissions-Policy was set to limit browser features such as camera, microphone, and geolocation.",
     "Add a Permissions-Policy header that disables features the site does not use."),
]


def check_security_headers(result: ScanResult) -> list[Finding]:
    headers = _headers_lower(result)
    findings = []
    for name, check_id, severity, why, fix in HEADER_CHECKS:
        if name not in headers:
            findings.append(Finding(
                check_id, f"Missing {name.title()} header", severity, "Security Headers",
                why, f"Header {name.title()} not present in response", fix))

    csp = headers.get("content-security-policy", "")
    if "x-frame-options" not in headers and "frame-ancestors" not in csp:
        findings.append(Finding(
            "WR-011", "No clickjacking protection", "Medium", "Security Headers",
            "Neither X-Frame-Options nor a CSP frame-ancestors directive was set, so the page "
            "can be embedded in a frame on another site and used for clickjacking.",
            "X-Frame-Options and CSP frame-ancestors both absent",
            "Add X-Frame-Options: DENY or a CSP frame-ancestors 'none' directive."))

    if _is_https(result):
        hsts = headers.get("strict-transport-security")
        if not hsts:
            findings.append(Finding(
                "WR-015", "Missing Strict-Transport-Security header", "Medium", "Security Headers",
                "Without HSTS, a user's first request can be downgraded to HTTP by an attacker on the network.",
                "Strict-Transport-Security not present",
                "Add Strict-Transport-Security: max-age=31536000; includeSubDomains."))
        else:
            match = re.search(r"max-age=(\d+)", hsts)
            if match and int(match.group(1)) < 15552000:
                findings.append(Finding(
                    "WR-016", "Weak HSTS max-age", "Low", "Security Headers",
                    "The HSTS max-age is shorter than six months, which limits its protection.",
                    f"Strict-Transport-Security: {hsts}",
                    "Raise max-age to at least 31536000 seconds."))
    return findings


# ---------------------------------------------------- information disclosure

def check_information_disclosure(result: ScanResult) -> list[Finding]:
    headers = _headers_lower(result)
    findings = []
    server = headers.get("server", "")
    if re.search(r"\d", server):
        findings.append(Finding(
            "WR-020", "Server version disclosed", "Low", "Information Disclosure",
            "The Server header reveals software version details, which helps an attacker "
            "look up known vulnerabilities for that exact version.",
            f"Server: {server}",
            "Configure the web server to hide version details, for example ServerTokens Prod "
            "in Apache or server_tokens off in Nginx."))
    for name in ("x-powered-by", "x-aspnet-version", "x-aspnetmvc-version", "x-generator"):
        if name in headers:
            findings.append(Finding(
                "WR-021", f"Technology disclosed in {name.title()} header", "Low",
                "Information Disclosure",
                "This header advertises the framework or platform behind the site.",
                f"{name.title()}: {headers[name]}",
                f"Remove the {name.title()} header from responses."))
    return findings


# ------------------------------------------------------------------- cookies

def check_cookies(result: ScanResult) -> list[Finding]:
    findings = []
    https = _is_https(result)
    for cookie in result.cookies:
        looks_like_session = any(h in cookie.name.lower() for h in SESSION_COOKIE_HINTS)
        problems = []
        if not cookie.secure:
            problems.append("Secure flag missing")
        if not cookie.httponly:
            problems.append("HttpOnly flag missing")
        if not cookie.samesite:
            problems.append("SameSite attribute missing")
        elif cookie.samesite.lower() == "none" and not cookie.secure:
            problems.append("SameSite=None used without Secure")
        if not problems:
            continue

        if looks_like_session and ("HttpOnly flag missing" in problems
                                   or ("Secure flag missing" in problems and https)):
            severity = "Medium"
        else:
            severity = "Low"

        findings.append(Finding(
            "WR-030", f"Insecure cookie attributes: {cookie.name}", severity, "Cookie Security",
            "Cookie flags limit how a cookie can be stolen or misused. Secure keeps it off "
            "plain HTTP, HttpOnly keeps it away from JavaScript, and SameSite limits cross-site "
            "request forgery." + (" The name suggests this is a session cookie." if looks_like_session else ""),
            f"{'; '.join(problems)}. Raw header: {cookie.raw}",
            "Set the cookie with Secure, HttpOnly, and SameSite=Lax or Strict."))
    return findings


# ---------------------------------------------------------------------- CORS

def check_cors(result: ScanResult) -> list[Finding]:
    headers = _headers_lower(result)
    origin = headers.get("access-control-allow-origin")
    if origin != "*":
        return []
    creds = headers.get("access-control-allow-credentials", "").lower() == "true"
    return [Finding(
        "WR-040", "Overly permissive CORS policy", "High" if creds else "Medium", "CORS",
        "Access-Control-Allow-Origin is set to a wildcard, so any website can read responses "
        "from this application in a visitor's browser.",
        f"Access-Control-Allow-Origin: *" + ("; Access-Control-Allow-Credentials: true" if creds else ""),
        "Restrict Access-Control-Allow-Origin to a list of trusted origins.")]


# ------------------------------------------------------------- HTTP methods

def check_http_methods(result: ScanResult) -> list[Finding]:
    findings = []
    if result.trace_enabled:
        findings.append(Finding(
            "WR-050", "HTTP TRACE method enabled", "Low", "HTTP Methods",
            "TRACE echoes the request back, which can expose headers and has been used in "
            "cross-site tracing attacks.",
            "TRACE request returned 200 with the request echoed",
            "Disable TRACE, for example TraceEnable Off in Apache."))
    risky = [m for m in result.allowed_methods if m in ("PUT", "DELETE", "PATCH", "CONNECT")]
    if risky:
        findings.append(Finding(
            "WR-051", "Potentially dangerous HTTP methods allowed", "Medium", "HTTP Methods",
            "The server advertises methods that can change or remove content. Verify they "
            "require authentication.",
            f"Allow: {', '.join(result.allowed_methods)}",
            "Disable methods the application does not need."))
    return findings


# ----------------------------------------------------- exposed files / dirs

def check_exposed_paths(result: ScanResult) -> list[Finding]:
    findings = []
    for probe in result.probes:
        if probe.status_code != 200:
            continue
        body = probe.body_snippet
        if probe.path == "/.git/HEAD" and body.strip().startswith("ref:"):
            findings.append(Finding(
                "WR-060", "Git repository exposed", "High", "Sensitive File Exposure",
                "The .git directory is reachable over the web. An attacker can often rebuild "
                "the full source code, including history and secrets.",
                f"{probe.url} returned: {body.strip()[:80]}",
                "Block access to .git in the web server config and remove it from the web root."))
        elif probe.path == "/.env" and re.search(r"^[A-Z_][A-Z0-9_]*=", body, re.M):
            findings.append(Finding(
                "WR-061", "Environment file exposed", "High", "Sensitive File Exposure",
                "A .env file is publicly readable. These files usually hold passwords, API keys, "
                "and database connection strings.",
                f"{probe.url} returned key=value content",
                "Remove the .env file from the web root, block it in the server config, and rotate every secret it contained."))
        elif probe.path == "/server-status" and "server status" in body.lower():
            findings.append(Finding(
                "WR-062", "Apache server-status page exposed", "Medium", "Information Disclosure",
                "The server-status page reveals client IPs, requested URLs, and server internals.",
                f"{probe.url} returned a server status page",
                "Restrict server-status to localhost or remove mod_status."))
        elif probe.path == "/phpinfo.php" and "phpinfo" in body.lower():
            findings.append(Finding(
                "WR-063", "phpinfo page exposed", "Medium", "Information Disclosure",
                "phpinfo output reveals PHP version, modules, paths, and environment variables.",
                f"{probe.url} returned phpinfo output",
                "Delete phpinfo.php from the server."))
        elif "index of" in body.lower():
            findings.append(Finding(
                "WR-064", f"Directory listing enabled at {probe.path}", "Medium", "Information Disclosure",
                "The server lists directory contents, letting anyone browse files that were never linked.",
                f"{probe.url} returned an 'Index of' page",
                "Disable directory listing, for example Options -Indexes in Apache."))

    listed = {urlparse(f.evidence.split(" ")[0]).path for f in findings if f.check_id == "WR-064"}
    for page in result.pages:
        path = urlparse(page.url).path or "/"
        if page.title.lower().startswith("index of") and path not in listed:
            listed.add(path)
            findings.append(Finding(
                "WR-064", f"Directory listing enabled at {path}", "Medium",
                "Information Disclosure",
                "The server lists directory contents, letting anyone browse files that were never linked.",
                f"{page.url} has title '{page.title}'",
                "Disable directory listing, for example Options -Indexes in Apache."))
    return findings


# --------------------------------------------------------------------- forms

def check_forms(result: ScanResult) -> list[Finding]:
    findings = []
    for form in result.forms:
        page_scheme = urlparse(form.page_url).scheme
        action_scheme = urlparse(form.action).scheme
        has_password = any(i["type"] == "password" for i in form.inputs)
        where = f"Form on {form.page_url} ({form.method} to {form.action})"

        if has_password and action_scheme == "http":
            findings.append(Finding(
                "WR-070", "Password submitted over HTTP", "High", "Forms",
                "A login or password form sends credentials without encryption.",
                where, "Serve the page and the form action over HTTPS only."))
        elif page_scheme == "https" and action_scheme == "http":
            findings.append(Finding(
                "WR-071", "HTTPS page posts form data to HTTP", "Medium", "Forms",
                "Form data entered on a secure page is sent to an insecure endpoint.",
                where, "Change the form action to an HTTPS URL."))

        if has_password and form.method == "GET":
            findings.append(Finding(
                "WR-072", "Password form uses GET", "Medium", "Forms",
                "With GET, the password ends up in the URL, browser history, and server logs.",
                where, "Change the form method to POST."))

        if form.method == "POST":
            names = [i["name"].lower() for i in form.inputs if i["type"] == "hidden"]
            if not any(h in n for n in names for h in CSRF_FIELD_HINTS):
                findings.append(Finding(
                    "WR-073", "POST form with no visible CSRF token", "Medium", "Forms",
                    "No hidden anti-CSRF token field was found. Unless the app protects against "
                    "CSRF another way, such as SameSite cookies or custom headers, an attacker's "
                    "site could submit this form as a logged-in user. Verify manually.",
                    where, "Add a per-session or per-request anti-CSRF token to state-changing forms."))

        for field_info in form.inputs:
            if field_info["type"] == "password" and field_info["autocomplete"] not in (
                    "off", "new-password", "current-password"):
                findings.append(Finding(
                    "WR-074", "Password field without autocomplete guidance", "Info", "Forms",
                    "The password field has no autocomplete attribute. This is informational; "
                    "modern guidance prefers current-password or new-password over turning it off.",
                    where, "Set autocomplete=\"current-password\" or \"new-password\" on password fields."))
    return findings


# -------------------------------------------------------------------- robots

def check_robots(result: ScanResult) -> list[Finding]:
    if not result.robots_txt:
        return []
    disallowed = [line.split(":", 1)[1].strip() for line in result.robots_txt.splitlines()
                  if line.lower().startswith("disallow:") and line.split(":", 1)[1].strip()]
    if not disallowed:
        return []
    return [Finding(
        "WR-080", "robots.txt lists hidden paths", "Info", "Reconnaissance",
        "robots.txt tells crawlers which paths to skip, but anyone can read it. Paths listed "
        "here are worth reviewing during testing.",
        "Disallowed: " + ", ".join(disallowed[:20]),
        "Do not rely on robots.txt to hide sensitive areas. Protect them with authentication.")]


ALL_CHECKS = [
    check_https,
    check_security_headers,
    check_information_disclosure,
    check_cookies,
    check_cors,
    check_http_methods,
    check_exposed_paths,
    check_forms,
    check_robots,
]


def analyze(result: ScanResult) -> list[Finding]:
    findings: list[Finding] = []
    if result.status_code is None:
        return findings
    for check in ALL_CHECKS:
        findings.extend(check(result))
    findings.sort(key=lambda f: (SEVERITY_ORDER[f.severity], f.check_id))
    return findings


def severity_counts(findings: list[Finding]) -> dict:
    counts = {s: 0 for s in SEVERITY_ORDER}
    for f in findings:
        counts[f.severity] += 1
    return counts
