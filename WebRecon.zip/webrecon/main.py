"""
main.py - Command-line entry point for WebRecon.

Usage:
    python main.py http://127.0.0.1:8080 -o report.html --json results.json

Only scan systems you own or have written permission to test.
"""

from __future__ import annotations

import argparse
import logging
import sys
from urllib.parse import urlparse

from analyzer import analyze, severity_counts, SEVERITY_ORDER
from report import write_html, write_json
from scanner import Scanner

BANNER = r"""
 __        __   _     ____
 \ \      / /__| |__ |  _ \ ___  ___ ___  _ __
  \ \ /\ / / _ \ '_ \| |_) / _ \/ __/ _ \| '_ \
   \ V  V /  __/ |_) |  _ <  __/ (_| (_) | | | |
    \_/\_/ \___|_.__/|_| \_\___|\___\___/|_| |_|
   IT 359 Team Red - Web Recon & Misconfiguration Scanner
"""

LOCAL_HOSTS = ("localhost", "127.0.0.1", "::1")


def parse_args(argv=None) -> argparse.Namespace:
    p = argparse.ArgumentParser(
        description="WebRecon: web application reconnaissance and security misconfiguration scanner. "
                    "For authorized testing only.")
    p.add_argument("target", help="Target URL, for example http://127.0.0.1:8080")
    p.add_argument("-o", "--output", default="webrecon_report.html", help="HTML report path")
    p.add_argument("--json", dest="json_path", help="Also write raw results and findings to this JSON file")
    p.add_argument("--max-pages", type=int, default=10, help="Maximum same-origin pages to crawl (default 10)")
    p.add_argument("--timeout", type=float, default=10.0, help="Request timeout in seconds (default 10)")
    p.add_argument("--delay", type=float, default=0.2, help="Delay between requests in seconds (default 0.2)")
    p.add_argument("--insecure", action="store_true", help="Skip TLS certificate verification (lab use)")
    p.add_argument("--no-probes", action="store_true", help="Skip the sensitive path probes")
    p.add_argument("--fail-on", choices=list(SEVERITY_ORDER), help="Exit with code 2 if any finding is at or above this severity")
    p.add_argument("-y", "--yes", action="store_true", help="Confirm you are authorized to scan the target without prompting")
    p.add_argument("-v", "--verbose", action="store_true", help="Verbose logging")
    return p.parse_args(argv)


def confirm_authorization(target: str, assume_yes: bool) -> bool:
    host = urlparse(target if "://" in target else "http://" + target).hostname or ""
    if host in LOCAL_HOSTS or assume_yes:
        return True
    print(f"[!] Target {host} is not a local address.")
    answer = input("[?] Do you have explicit authorization to test this target? (yes/no): ")
    return answer.strip().lower() in ("y", "yes")


def main(argv=None) -> int:
    args = parse_args(argv)
    logging.basicConfig(level=logging.INFO if args.verbose else logging.WARNING,
                        format="[%(levelname)s] %(name)s: %(message)s")
    print(BANNER)

    if not confirm_authorization(args.target, args.yes):
        print("[-] Scan cancelled. Only scan systems you are authorized to test.")
        return 1

    scanner = Scanner(args.target, timeout=args.timeout, max_pages=args.max_pages,
                      delay=args.delay, verify_tls=not args.insecure, run_probes=not args.no_probes)
    print(f"[*] Scanning {scanner.target} ...")
    result = scanner.run()

    if result.status_code is None:
        print("[-] Could not reach the target.")
        for err in result.errors:
            print(f"    {err}")
        return 1

    findings = analyze(result)
    counts = severity_counts(findings)

    print(f"[+] {result.final_url} responded {result.status_code}")
    print(f"[+] Crawled {len(result.pages)} page(s), {len(result.forms)} form(s), {len(result.cookies)} cookie(s)")
    print(f"[+] {len(findings)} finding(s): " + ", ".join(f"{k} {v}" for k, v in counts.items()))
    for f in findings:
        print(f"    [{f.severity:<8}] {f.check_id}  {f.title}")

    write_html(result, findings, args.output)
    print(f"[+] HTML report written to {args.output}")
    if args.json_path:
        write_json(result, findings, args.json_path)
        print(f"[+] JSON results written to {args.json_path}")

    if args.fail_on:
        threshold = SEVERITY_ORDER[args.fail_on]
        if any(SEVERITY_ORDER[f.severity] <= threshold for f in findings):
            return 2
    return 0


if __name__ == "__main__":
    sys.exit(main())
