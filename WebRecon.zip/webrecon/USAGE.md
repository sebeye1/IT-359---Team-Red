# Running WebRecon

## Setup

```
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

## Scan a target

```
python main.py http://127.0.0.1:8080 -o report.html --json results.json
```

| Option | What it does |
| --- | --- |
| `-o`, `--output` | HTML report path, default `webrecon_report.html` |
| `--json` | Also save raw scan data and findings as JSON |
| `--max-pages` | Same-origin pages to crawl, default 10 |
| `--timeout` | Request timeout in seconds, default 10 |
| `--delay` | Pause between requests in seconds, default 0.2 |
| `--insecure` | Skip TLS certificate checks for self-signed lab certs |
| `--no-probes` | Skip the sensitive path probes |
| `--fail-on` | Exit with code 2 if any finding is at or above a severity |
| `-y` | Confirm authorization for a non-local target without the prompt |
| `-v` | Verbose logging |

Non-local targets require confirmation that you are authorized to test them.

## Lab and remediation demo

`lab/vulnerable_lab.py` is a deliberately misconfigured app that only listens on 127.0.0.1.

```
# Terminal 1
python lab/vulnerable_lab.py

# Terminal 2
python main.py http://127.0.0.1:8080 -o before.html
```

Stop the lab, restart it with `--hardened`, and scan again into `after.html`. The before scan
reports 21 findings and the after scan reports 3. The remaining 3 are expected because the lab
runs over plain HTTP, which is a good talking point for the demo.

## Tests

```
pytest -q
```

## Project layout

| File | Role |
| --- | --- |
| `main.py` | Command-line interface, authorization check, console summary |
| `scanner.py` | Reconnaissance: fetch, crawl, headers, cookies, links, forms, methods, path probes |
| `analyzer.py` | Security checks, severity classification, remediation advice |
| `report.py` | HTML and JSON report output |
| `lab/vulnerable_lab.py` | Local practice target with vulnerable and hardened modes |
| `tests/test_webrecon.py` | Offline unit tests |

## Checks

| ID | Check | Severity |
| --- | --- | --- |
| WR-001 | Site served over HTTP | Medium |
| WR-010 to WR-016 | Missing or weak security headers: CSP, clickjacking, nosniff, Referrer-Policy, Permissions-Policy, HSTS | Info to Medium |
| WR-020, WR-021 | Server version and technology header disclosure | Low |
| WR-030 | Cookies missing Secure, HttpOnly, or SameSite | Low to Medium |
| WR-040 | Wildcard CORS, High when credentials are allowed | Medium to High |
| WR-050, WR-051 | TRACE enabled, risky methods allowed | Low to Medium |
| WR-060 to WR-064 | Exposed .git, .env, server-status, phpinfo, directory listing | Medium to High |
| WR-070 to WR-074 | Password over HTTP, HTTPS to HTTP forms, password via GET, missing CSRF token, autocomplete | Info to High |
| WR-080 | robots.txt disallowed paths | Info |
