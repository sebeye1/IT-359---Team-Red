"""
scanner.py - Reconnaissance module for WebRecon.

Collects observable information from an authorized target: HTTP response
details, headers, cookies, links, forms, robots.txt, supported HTTP methods,
and a small set of low-impact path probes. This module only gathers data.
All judgments about what is a finding live in analyzer.py.
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field, asdict
from urllib.parse import urljoin, urlparse, urldefrag

import requests
from bs4 import BeautifulSoup

log = logging.getLogger(__name__)

USER_AGENT = "WebRecon/1.0 (IT 359 Team Red - authorized testing only)"

# Low-impact GET probes. Each one is checked for a content signature in
# analyzer.py so a custom 200 "not found" page does not cause a false positive.
PROBE_PATHS = [
    "/robots.txt",
    "/.git/HEAD",
    "/.env",
    "/server-status",
    "/phpinfo.php",
    "/uploads/",
    "/backup/",
    "/images/",
]


@dataclass
class Cookie:
    name: str
    secure: bool = False
    httponly: bool = False
    samesite: str | None = None
    path: str | None = None
    domain: str | None = None
    source_url: str = ""
    raw: str = ""


@dataclass
class Form:
    page_url: str
    action: str
    method: str
    inputs: list = field(default_factory=list)  # list of {"name", "type", "autocomplete"}


@dataclass
class PageInfo:
    url: str
    status_code: int
    title: str = ""
    content_type: str = ""


@dataclass
class ProbeResult:
    path: str
    url: str
    status_code: int | None
    content_type: str = ""
    body_snippet: str = ""


@dataclass
class ScanResult:
    target: str
    final_url: str = ""
    status_code: int | None = None
    redirect_chain: list = field(default_factory=list)
    headers: dict = field(default_factory=dict)
    cookies: list = field(default_factory=list)
    pages: list = field(default_factory=list)
    links: list = field(default_factory=list)
    external_links: list = field(default_factory=list)
    forms: list = field(default_factory=list)
    robots_txt: str | None = None
    allowed_methods: list = field(default_factory=list)
    trace_enabled: bool = False
    probes: list = field(default_factory=list)
    errors: list = field(default_factory=list)
    started: str = ""
    finished: str = ""

    def to_dict(self) -> dict:
        return asdict(self)


def parse_set_cookie(header_value: str, source_url: str) -> Cookie:
    """Parse one raw Set-Cookie header, keeping the security attributes."""
    parts = [p.strip() for p in header_value.split(";")]
    name = parts[0].split("=", 1)[0].strip()
    cookie = Cookie(name=name, source_url=source_url, raw=header_value)
    for attr in parts[1:]:
        key, _, value = attr.partition("=")
        key = key.strip().lower()
        if key == "secure":
            cookie.secure = True
        elif key == "httponly":
            cookie.httponly = True
        elif key == "samesite":
            cookie.samesite = value.strip() or None
        elif key == "path":
            cookie.path = value.strip()
        elif key == "domain":
            cookie.domain = value.strip()
    return cookie


def _raw_set_cookies(response: requests.Response) -> list[str]:
    """Return every Set-Cookie header separately. requests merges them otherwise."""
    raw_headers = getattr(response.raw, "headers", None)
    if raw_headers is not None and hasattr(raw_headers, "getlist"):
        return raw_headers.getlist("Set-Cookie")
    value = response.headers.get("Set-Cookie")
    return [value] if value else []


def parse_forms(soup: BeautifulSoup, page_url: str) -> list[Form]:
    forms = []
    for form in soup.find_all("form"):
        action = urljoin(page_url, form.get("action") or page_url)
        method = (form.get("method") or "GET").upper()
        inputs = []
        for field_tag in form.find_all(["input", "textarea", "select"]):
            inputs.append({
                "name": field_tag.get("name", ""),
                "type": (field_tag.get("type") or field_tag.name).lower(),
                "autocomplete": (field_tag.get("autocomplete") or "").lower(),
            })
        forms.append(Form(page_url=page_url, action=action, method=method, inputs=inputs))
    return forms


def parse_links(soup: BeautifulSoup, page_url: str) -> list[str]:
    links = []
    for tag in soup.find_all("a", href=True):
        href = tag["href"].strip()
        if href.startswith(("mailto:", "javascript:", "tel:", "#")):
            continue
        absolute, _ = urldefrag(urljoin(page_url, href))
        links.append(absolute)
    return links


def same_origin(url_a: str, url_b: str) -> bool:
    a, b = urlparse(url_a), urlparse(url_b)
    return (a.scheme, a.netloc) == (b.scheme, b.netloc)


class Scanner:
    def __init__(self, target: str, timeout: float = 10.0, max_pages: int = 10,
                 delay: float = 0.2, verify_tls: bool = True, run_probes: bool = True):
        if not urlparse(target).scheme:
            target = "http://" + target
        self.target = target
        self.timeout = timeout
        self.max_pages = max(1, max_pages)
        self.delay = delay
        self.run_probes = run_probes
        self.session = requests.Session()
        self.session.headers["User-Agent"] = USER_AGENT
        self.session.verify = verify_tls
        self.result = ScanResult(target=target)

    def _request(self, method: str, url: str, **kwargs) -> requests.Response | None:
        try:
            response = self.session.request(method, url, timeout=self.timeout, **kwargs)
            time.sleep(self.delay)
            return response
        except requests.RequestException as exc:
            message = f"{method} {url} failed: {exc.__class__.__name__}: {exc}"
            log.warning(message)
            self.result.errors.append(message)
            return None

    def _collect_cookies(self, response: requests.Response) -> None:
        # The same cookie is usually set on many pages. Keep one entry per name
        # and flag combination so each distinct configuration is reported once.
        def key(c: Cookie):
            return (c.name, c.secure, c.httponly, (c.samesite or "").lower())

        seen = {key(c) for c in self.result.cookies}
        for resp in list(response.history) + [response]:
            for raw in _raw_set_cookies(resp):
                cookie = parse_set_cookie(raw, resp.url)
                if key(cookie) not in seen:
                    self.result.cookies.append(cookie)
                    seen.add(key(cookie))

    def fetch_main(self) -> bool:
        log.info("Fetching %s", self.target)
        response = self._request("GET", self.target, allow_redirects=True)
        if response is None:
            return False
        r = self.result
        r.final_url = response.url
        r.status_code = response.status_code
        r.redirect_chain = [f"{h.status_code} {h.url}" for h in response.history]
        r.headers = dict(response.headers)
        self._collect_cookies(response)
        return True

    def crawl(self) -> None:
        """Breadth-first crawl of same-origin pages, capped at max_pages."""
        start = self.result.final_url or self.target
        queue, visited = [start], set()
        all_links: set[str] = set()
        while queue and len(visited) < self.max_pages:
            url = queue.pop(0)
            if url in visited:
                continue
            visited.add(url)
            response = self._request("GET", url, allow_redirects=True)
            if response is None:
                continue
            self._collect_cookies(response)
            content_type = response.headers.get("Content-Type", "")
            page = PageInfo(url=response.url, status_code=response.status_code,
                            content_type=content_type)
            if "html" in content_type.lower():
                soup = BeautifulSoup(response.text, "html.parser")
                if soup.title and soup.title.string:
                    page.title = soup.title.string.strip()
                self.result.forms.extend(parse_forms(soup, response.url))
                for link in parse_links(soup, response.url):
                    all_links.add(link)
                    if same_origin(link, start) and link not in visited:
                        queue.append(link)
            self.result.pages.append(page)
            log.info("Crawled %s (%s)", response.url, response.status_code)
        self.result.links = sorted(l for l in all_links if same_origin(l, start))
        self.result.external_links = sorted(l for l in all_links if not same_origin(l, start))

    def check_methods(self) -> None:
        base = self.result.final_url or self.target
        response = self._request("OPTIONS", base)
        if response is not None:
            allow = response.headers.get("Allow", "")
            self.result.allowed_methods = [m.strip().upper() for m in allow.split(",") if m.strip()]
        response = self._request("TRACE", base)
        if response is not None and response.status_code == 200 and "TRACE" in response.text.upper():
            self.result.trace_enabled = True

    def probe_paths(self) -> None:
        base = self.result.final_url or self.target
        for path in PROBE_PATHS:
            url = urljoin(base, path)
            response = self._request("GET", url, allow_redirects=False)
            if response is None:
                continue
            probe = ProbeResult(
                path=path, url=url, status_code=response.status_code,
                content_type=response.headers.get("Content-Type", ""),
                body_snippet=response.text[:2000] if response.status_code == 200 else "",
            )
            self.result.probes.append(probe)
            if path == "/robots.txt" and response.status_code == 200:
                self.result.robots_txt = response.text[:5000]

    def run(self) -> ScanResult:
        self.result.started = time.strftime("%Y-%m-%d %H:%M:%S")
        if self.fetch_main():
            self.crawl()
            self.check_methods()
            if self.run_probes:
                self.probe_paths()
        self.result.finished = time.strftime("%Y-%m-%d %H:%M:%S")
        return self.result
