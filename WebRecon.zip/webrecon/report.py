"""
report.py - Report generation for WebRecon.

Builds a standalone HTML security assessment report (no external CSS or JS)
and an optional JSON export of the raw scan data and findings.
"""

from __future__ import annotations

import json
from html import escape

from analyzer import Finding, severity_counts
from scanner import ScanResult

SEVERITY_COLORS = {
    "Critical": "#7b1fa2", "High": "#c62828", "Medium": "#ef6c00",
    "Low": "#f9a825", "Info": "#1565c0",
}

CSS = """
body{font-family:Segoe UI,Helvetica,Arial,sans-serif;margin:0;background:#f4f5f7;color:#1f2328}
header{background:#8b0000;color:#fff;padding:24px 40px}
header h1{margin:0 0 4px;font-size:26px}
header p{margin:2px 0;opacity:.9}
main{max-width:1100px;margin:0 auto;padding:24px 40px}
section{background:#fff;border-radius:8px;padding:20px 24px;margin-bottom:20px;box-shadow:0 1px 3px rgba(0,0,0,.08)}
h2{margin-top:0;font-size:20px;border-bottom:2px solid #eee;padding-bottom:8px}
table{border-collapse:collapse;width:100%;font-size:14px}
th,td{text-align:left;padding:8px 10px;border-bottom:1px solid #eee;vertical-align:top}
th{background:#fafafa}
.sev{display:inline-block;padding:2px 10px;border-radius:12px;color:#fff;font-size:12px;font-weight:600}
.cards{display:flex;gap:12px;flex-wrap:wrap}
.card{flex:1;min-width:110px;border-radius:8px;padding:14px;color:#fff;text-align:center}
.card .n{font-size:28px;font-weight:700}
.finding{border-left:5px solid #ccc;padding:12px 16px;margin:14px 0;background:#fcfcfc;border-radius:4px}
.finding h3{margin:0 0 6px;font-size:16px}
.label{font-weight:600}
code,pre{font-family:Consolas,monospace;font-size:13px;background:#f0f0f0;border-radius:4px}
code{padding:1px 4px}
pre{padding:10px;white-space:pre-wrap;word-break:break-all}
.muted{color:#666}
footer{text-align:center;color:#888;font-size:12px;padding:20px}
"""


def _badge(severity: str) -> str:
    return f'<span class="sev" style="background:{SEVERITY_COLORS[severity]}">{escape(severity)}</span>'


def _table(rows: list[tuple], headers: tuple) -> str:
    if not rows:
        return '<p class="muted">None found.</p>'
    head = "".join(f"<th>{escape(h)}</th>" for h in headers)
    body = "".join("<tr>" + "".join(f"<td>{escape(str(c))}</td>" for c in row) + "</tr>" for row in rows)
    return f"<table><tr>{head}</tr>{body}</table>"


def _overall_risk(counts: dict) -> str:
    for level in ("Critical", "High", "Medium", "Low"):
        if counts[level]:
            return level
    return "Info"


def build_html(result: ScanResult, findings: list[Finding]) -> str:
    counts = severity_counts(findings)
    risk = _overall_risk(counts)

    cards = "".join(
        f'<div class="card" style="background:{SEVERITY_COLORS[s]}"><div class="n">{n}</div>{s}</div>'
        for s, n in counts.items())

    summary_rows = [(f.severity, f.check_id, f.title, f.category) for f in findings]

    detail = []
    for i, f in enumerate(findings, 1):
        detail.append(f"""
        <div class="finding" style="border-left-color:{SEVERITY_COLORS[f.severity]}">
          <h3>{i}. {escape(f.title)} {_badge(f.severity)}</h3>
          <p class="muted">{escape(f.check_id)} | {escape(f.category)}</p>
          <p><span class="label">Description:</span> {escape(f.description)}</p>
          <p><span class="label">Evidence:</span> <code>{escape(f.evidence)}</code></p>
          <p><span class="label">Recommendation:</span> {escape(f.recommendation)}</p>
        </div>""")

    header_rows = sorted(result.headers.items())
    cookie_rows = [(c.name, "Yes" if c.secure else "No", "Yes" if c.httponly else "No",
                    c.samesite or "Not set", c.source_url) for c in result.cookies]
    form_rows = [(f.page_url, f.method, f.action,
                  ", ".join(f"{i['name'] or '(unnamed)'} [{i['type']}]" for i in f.inputs))
                 for f in result.forms]
    page_rows = [(p.status_code, p.url, p.title) for p in result.pages]
    probe_rows = [(p.path, p.status_code) for p in result.probes]
    methods = ", ".join(result.allowed_methods) or "Not advertised"

    errors = ""
    if result.errors:
        errors = "<section><h2>Scan Errors</h2><ul>" + "".join(
            f"<li>{escape(e)}</li>" for e in result.errors) + "</ul></section>"

    return f"""<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>WebRecon Report - {escape(result.target)}</title>
<style>{CSS}</style></head>
<body>
<header>
  <h1>WebRecon Security Assessment Report</h1>
  <p>Target: {escape(result.target)}</p>
  <p>Scan window: {escape(result.started)} to {escape(result.finished)}</p>
</header>
<main>
<section>
  <h2>Executive Summary</h2>
  <p>WebRecon performed automated reconnaissance and configuration analysis against
  <code>{escape(result.final_url or result.target)}</code>. The scan crawled {len(result.pages)} page(s),
  found {len(result.forms)} form(s) and {len(result.cookies)} cookie(s), and identified
  <strong>{len(findings)}</strong> finding(s). Overall risk rating: {_badge(risk)}</p>
  <div class="cards">{cards}</div>
  <p class="muted">Automated results should be manually verified. This scan was limited to an
  authorized testing environment and did not attempt exploitation.</p>
</section>
<section><h2>Findings Summary</h2>{_table(summary_rows, ("Severity", "ID", "Finding", "Category"))}</section>
<section><h2>Detailed Findings</h2>{"".join(detail) or '<p class="muted">No findings.</p>'}</section>
<section>
  <h2>Reconnaissance Data</h2>
  <p><span class="label">Final URL:</span> {escape(result.final_url)} |
     <span class="label">Status:</span> {escape(str(result.status_code))} |
     <span class="label">Allowed methods:</span> {escape(methods)} |
     <span class="label">TRACE enabled:</span> {"Yes" if result.trace_enabled else "No"}</p>
  <p><span class="label">Redirect chain:</span> {escape(" -> ".join(result.redirect_chain)) or "None"}</p>
  <h3>Response Headers</h3>{_table(header_rows, ("Header", "Value"))}
  <h3>Cookies</h3>{_table(cookie_rows, ("Name", "Secure", "HttpOnly", "SameSite", "Set by"))}
  <h3>Pages Crawled</h3>{_table(page_rows, ("Status", "URL", "Title"))}
  <h3>Forms</h3>{_table(form_rows, ("Page", "Method", "Action", "Inputs"))}
  <h3>Internal Links ({len(result.links)})</h3>{_table([(l,) for l in result.links], ("URL",))}
  <h3>External Links ({len(result.external_links)})</h3>{_table([(l,) for l in result.external_links], ("URL",))}
  <h3>Path Probes</h3>{_table(probe_rows, ("Path", "Status"))}
  <h3>robots.txt</h3>{f"<pre>{escape(result.robots_txt)}</pre>" if result.robots_txt else '<p class="muted">Not found.</p>'}
</section>
{errors}
</main>
<footer>Generated by WebRecon | IT 359 Team Red | For authorized testing only</footer>
</body></html>"""


def write_html(result: ScanResult, findings: list[Finding], path: str) -> None:
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(build_html(result, findings))


def write_json(result: ScanResult, findings: list[Finding], path: str) -> None:
    payload = {
        "scan": result.to_dict(),
        "summary": severity_counts(findings),
        "findings": [f.to_dict() for f in findings],
    }
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(payload, fh, indent=2)
