"""Offline unit tests for WebRecon. Run with: pytest -q"""

from bs4 import BeautifulSoup

import analyzer
from report import build_html
from scanner import Form, ProbeResult, ScanResult, parse_forms, parse_set_cookie


def base_result(**overrides):
    r = ScanResult(target="http://127.0.0.1:8080", final_url="http://127.0.0.1:8080/", status_code=200)
    for key, value in overrides.items():
        setattr(r, key, value)
    return r


def ids(findings):
    return {f.check_id for f in findings}


def test_parse_set_cookie_flags():
    c = parse_set_cookie("sessionid=abc; Path=/; Secure; HttpOnly; SameSite=Strict", "http://x/")
    assert c.name == "sessionid" and c.secure and c.httponly and c.samesite == "Strict"


def test_parse_forms_resolves_action_and_inputs():
    html = '<form action="/login" method="post"><input type="password" name="pw"></form>'
    forms = parse_forms(BeautifulSoup(html, "html.parser"), "http://x/page")
    assert forms[0].action == "http://x/login"
    assert forms[0].method == "POST"
    assert forms[0].inputs[0]["type"] == "password"


def test_http_target_flagged():
    assert "WR-001" in ids(analyzer.check_https(base_result()))


def test_missing_headers_flagged_and_present_headers_not():
    findings = analyzer.check_security_headers(base_result(headers={}))
    assert {"WR-010", "WR-011", "WR-012"} <= ids(findings)
    good = base_result(headers={
        "Content-Security-Policy": "default-src 'self'; frame-ancestors 'none'",
        "X-Content-Type-Options": "nosniff", "Referrer-Policy": "no-referrer",
        "Permissions-Policy": "camera=()"})
    assert analyzer.check_security_headers(good) == []


def test_server_version_disclosure():
    r = base_result(headers={"Server": "Apache/2.4.29", "X-Powered-By": "PHP/7.2"})
    assert {"WR-020", "WR-021"} <= ids(analyzer.check_information_disclosure(r))


def test_insecure_session_cookie_is_medium():
    r = base_result(cookies=[parse_set_cookie("sessionid=1; Path=/", "http://x/")])
    findings = analyzer.check_cookies(r)
    assert findings and findings[0].severity == "Medium"


def test_secure_cookie_not_flagged():
    r = base_result(cookies=[parse_set_cookie("sessionid=1; Secure; HttpOnly; SameSite=Lax", "http://x/")])
    assert analyzer.check_cookies(r) == []


def test_cors_wildcard_with_credentials_is_high():
    r = base_result(headers={"Access-Control-Allow-Origin": "*", "Access-Control-Allow-Credentials": "true"})
    assert analyzer.check_cors(r)[0].severity == "High"


def test_exposed_git_requires_signature():
    real = ProbeResult("/.git/HEAD", "http://x/.git/HEAD", 200, body_snippet="ref: refs/heads/main")
    soft404 = ProbeResult("/.git/HEAD", "http://x/.git/HEAD", 200, body_snippet="<html>Page not found</html>")
    assert "WR-060" in ids(analyzer.check_exposed_paths(base_result(probes=[real])))
    assert analyzer.check_exposed_paths(base_result(probes=[soft404])) == []


def test_password_form_over_http_and_no_csrf():
    form = Form("http://x/login", "http://x/login", "POST",
                [{"name": "password", "type": "password", "autocomplete": ""}])
    assert {"WR-070", "WR-073"} <= ids(analyzer.check_forms(base_result(forms=[form])))


def test_csrf_token_suppresses_finding():
    form = Form("http://x/c", "http://x/c", "POST", [{"name": "csrf_token", "type": "hidden", "autocomplete": ""}])
    assert "WR-073" not in ids(analyzer.check_forms(base_result(forms=[form])))


def test_findings_sorted_by_severity():
    r = base_result(headers={"Server": "Apache/2.4.29"},
                    probes=[ProbeResult("/.env", "http://x/.env", 200, body_snippet="DB_PASSWORD=x")])
    order = [analyzer.SEVERITY_ORDER[f.severity] for f in analyzer.analyze(r)]
    assert order == sorted(order)


def test_unreachable_target_gives_no_findings():
    assert analyzer.analyze(ScanResult(target="http://x")) == []


def test_report_escapes_html():
    r = base_result(headers={"X-Test": "<script>alert(1)</script>"})
    html = build_html(r, analyzer.analyze(r))
    assert "<script>alert(1)</script>" not in html
    assert "&lt;script&gt;" in html
